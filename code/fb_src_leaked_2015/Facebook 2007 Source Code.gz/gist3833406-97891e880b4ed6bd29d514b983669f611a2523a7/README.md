In August 2007 a hacker found a way to expose the PHP source code on facebook.com. He retrieved two files and then emailed them to me, and I wrote about the issue:

http://techcrunch.com/2007/08/11/facebook-source-code-leaked/

It became a big deal:

http://www.techmeme.com/070812/p1#a070812p1

The two files are index.php (the homepage) and search.php (the search page)

I don't know what ended up happening to the guy who stole the code.

I found these files today while searching for another Facebook related file. Worth preserving as part of Internet history.

-- [nik](http://twitter.com/nikcub)